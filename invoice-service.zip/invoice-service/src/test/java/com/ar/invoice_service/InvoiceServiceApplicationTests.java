package com.ar.invoice_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoiceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
